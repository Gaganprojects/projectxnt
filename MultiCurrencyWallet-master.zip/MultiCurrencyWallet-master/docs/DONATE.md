# Donate to MultiCurrencyWallet

- BTC: (soon)
- LTC: (soon)
- ETH: (soon)
- GHOST: GYLgH4cF5AWmSTeeKzVySob2QzFzJS3z86


# Comparsion


## [MultiCurrencyWallet](https://swaponline.io) [(source)](https://github.com/swaponline)

open-source: ✔️
currencies: BTC, ETH, USDT, GHOST, NEXT, any ERC20 token
fiat gateway: ✔️ (USD, EUR, RUB, UAH, KRW, INR, GBP, TRY, BRL, AUD)
built-in wallet: ✔️
external wallets: ✔️ (Metamask)
i18n: ✔️ (EN, RU, NL, ES)
mobile version: ✔️
no registration: ✔️
embeddable: ✔️ ((Wordpress plugin)[https://codecanyon.net/item/multicurrency-crypto-wallet-and-exchange-widgets-for-wordpress/23532064])
additional: invoices


## [liquality](https://liquality.io/swap/) [(source)](https://github.com/liquality)

open-source: ✔️
currencies: BTC, ETH, WBTC, DAI, USDC, USDT
fiat gateway: 🚫
built-in wallet: 🚫
external wallets: ✔️ (Ledger, Metamask)
i18n: 🚫
mobile version: 🚫
no registration: ✔️
embeddable: 🚫
additional: 🚫


## ShapeShift

open-source: 🚫
currencies: ?
fiat gateway: ?
built-in wallet: ?
external wallets: ?
i18n: ?
mobile version: ?
no registration: 🚫
embeddable: ✔️ ((Wordpress plugin)[https://codecanyon.net/item/cryptocurrency-exchange-shapeshift-wordpress-plugin/21472491])
additional: ?

https://codecanyon.net/item/cryptocurrency-exchange-shapeshift-wordpress-plugin/21472491


## [OneSwap](https://www.oneswap.net/eth/swap) [(source)](https://github.com/oneswap)

open-source: ±
...


## [Atomex](https://wallet.atomex.me/) [(source)](https://github.com/atomex-me)

...
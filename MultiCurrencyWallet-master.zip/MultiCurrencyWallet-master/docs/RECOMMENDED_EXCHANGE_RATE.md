# RECOMMENDED EXCHANGE RATE

It used in the application only for widget's tokens in:

1) Wallet table (Calculating fiat balance for tokens wallet);
2) Total balance (Adding tokens balance to total sum of all added wallets);
3) Transaction history (Calculating fiat amount for tokens transactions);
4) When creating an atomic swap order (Display this rate for user).

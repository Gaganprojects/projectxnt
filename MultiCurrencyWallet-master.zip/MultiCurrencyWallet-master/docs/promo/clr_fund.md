
clr.fund (https://clr.fund/):
1) для фандинга они используют evm XDAI (https://www.xdaichain.com/)
2) нужно законектиться через метамаск и залить туда 20 XDAI  (+ комиссии за транзакции скорее всего) через бридж (https://bridge.xdaichain.com/)
3) заполняем форму подачи, сабмитим проект и ждем 3 дня для процесса ревью
4) пока не понятно что нужно будет дальше…

Listing Policy - https://ipfs.io/ipfs/QmeygKjvrpidJeFHv6ywjUrj718nwtFQgCCPPR4r5nL87R

<img width="542" alt="Screen Shot 2021-07-28 at 12 57 04" src="https://user-images.githubusercontent.com/36531102/127296608-754e7ba0-b386-40f9-9ab0-3bfd9ca2309b.png">

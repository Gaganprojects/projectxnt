/**
  move code from src\core\simple\src\instances\ethereum.js
  merge with from
  use src\front\shared\instances\newSwap
  
  add estimateGas (front+bot)
**/
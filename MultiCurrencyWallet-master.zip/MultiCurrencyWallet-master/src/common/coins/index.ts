import getCoinInfo from './getCoinInfo'

export default {
  getCoinInfo
}
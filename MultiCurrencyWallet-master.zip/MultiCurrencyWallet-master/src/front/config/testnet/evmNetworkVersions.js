export default [
    4,      // ETH Testnet (Rinkeby)
    97,     // BSC Testnet
    80001,  // MATIC Testnet
    421611, // ARBITRUM Testnet (Rinkeby)
    77,     // XDAI Testnet (Sokol)
]
export default {
  wbtc: {
    address: '0xeb8df6700e24802a5d435e5b0e4228065ca9e0f3',
    decimals: 8,
    fullName: 'Wrapped Bitcoin',
    canSwap: true,
  },
}

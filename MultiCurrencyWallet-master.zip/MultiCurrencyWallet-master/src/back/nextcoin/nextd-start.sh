nextd -daemon -server -rpcuser=test -rpcpassword=test -txindex -reindex-chainstate -addressindex -timestampindex -spentindex
echo 'nextd started!'
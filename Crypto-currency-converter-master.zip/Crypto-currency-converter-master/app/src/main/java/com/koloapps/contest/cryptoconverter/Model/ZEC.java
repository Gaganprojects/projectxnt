package com.koloapps.contest.cryptoconverter.Model;

public class ZEC {
    private double USD;

    public double getUSD() {
        return USD;
    }

    public void setUSD(double USD) {
        this.USD = USD;
    }
}

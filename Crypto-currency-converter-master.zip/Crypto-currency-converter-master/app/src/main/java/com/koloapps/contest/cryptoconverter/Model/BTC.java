package com.koloapps.contest.cryptoconverter.Model;



/**
 * Created by Johnjahnless on 11/1/2017.
 */

public class BTC {
    //Getter & Setter BTC object for USD
    private double USD;

    public double getUSD() {
        return USD;
    }

    public void setUSD(double USD) {
        this.USD = USD;
    }
}  
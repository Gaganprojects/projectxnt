package com.koloapps.contest.cryptoconverter.Model;


/**
 * Created by Johnjahnless on 11/1/2017.
 */




public class ETH {
    //Getter & Setter ETH object(USD)
    private double USD;

    public double getUSD() {
        return USD;
    }

    public void setUSD(double USD) {
        this.USD = USD;
    }
}
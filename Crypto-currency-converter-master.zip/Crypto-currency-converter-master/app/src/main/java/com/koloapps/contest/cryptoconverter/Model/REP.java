package com.koloapps.contest.cryptoconverter.Model;

public class REP {
    private double USD;

    public double getUSD() {
        return USD;
    }

    public void setUSD(double USD) {
        this.USD = USD;
    }
}

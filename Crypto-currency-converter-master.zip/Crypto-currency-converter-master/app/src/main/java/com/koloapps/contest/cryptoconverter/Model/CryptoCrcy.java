package com.koloapps.contest.cryptoconverter.Model;


/**
 * Created by Johnjahnless on 11/1/2017.
 */


public class CryptoCrcy {
    //Create getter & setter for response objects
    private BTC BTC;
    private ETH ETH;
    private ADA ADA;
    private BCH BCH;
    private DASH DASH;
    private EOS EOS;
    private LTC LTC;
    private DOGE DOGE;
    private PPC PPC;
    private NEO NEO;
    private REP REP;
    private XMR XMR;
    private XRP XRP;
    private ZEC ZEC;

    public BTC getBTC() {
        return BTC;
    }

    public void setBTC(BTC BTC) {
        this.BTC = BTC;
    }

    public ETH getETH() {
        return ETH;
    }

    public void setETH(ETH ETH) {
        this.ETH = ETH;
    }

    public ADA getADA() {
        return ADA;
    }

    public void setADA(ADA ADA) {
        this.ADA = ADA;
    }

    public BCH getBCH() {
        return BCH;
    }

    public void setBCH(BCH BCH) {
        this.BCH = BCH;
    }

    public DASH getDASH() {
        return DASH;
    }

    public void setDASH(DASH DASH) {
        this.DASH = DASH;
    }

    public EOS getEOS() {
        return EOS;
    }

    public void setEOS(EOS EOS) {
        this.EOS = EOS;
    }

    public LTC getLTC() {
        return LTC;
    }

    public void setLTC(LTC LTC) {
        this.LTC = LTC;
    }

    public DOGE getDOGE() {
        return DOGE;
    }

    public void setDOGE(DOGE DOGE) {
        this.DOGE = DOGE;
    }

    public PPC getPPC() {
        return PPC;
    }

    public void setPPC(PPC PPC) {
        this.PPC = PPC;
    }

    public NEO getNEO() {
        return NEO;
    }

    public void setNEO(NEO NEO) {
        this.NEO = NEO;
    }

    public REP getREP() {
        return REP;
    }

    public void setREP(REP REP) {
        this.REP = REP;
    }

    public XMR getXMR() {
        return XMR;
    }

    public void setXMR(XMR XMR) {
        this.XMR = XMR;
    }
    public XRP getXRP() {
        return XRP;
    }

    public void setXRP(XRP XRP) {
        this.XRP = XRP;
    }

    public ZEC getZEC() {
        return ZEC;
    }

    public void setZEC(ZEC ZEC) {
        this.ZEC = ZEC;
    }
}

# Crypto-currency-converter
An adroid app that converts cryptocurrency such as bitcoin, ethererum, litecoin, dogecoin e.t.c to your country local currency
![web-build_2018-10-10t00_53_54 933z_ti8q 2fnexus4-19-en_us-portrait 2fartifacts 2f2](https://user-images.githubusercontent.com/32623706/46898091-c8828c00-ce7e-11e8-98c4-47c9143f7b03.png)
![web-build_2018-10-10t00_53_54 933z_ti8q 2fnexus4-19-en_us-portrait 2fartifacts 2f3](https://user-images.githubusercontent.com/32623706/46898092-c8828c00-ce7e-11e8-993b-db9404594ad8.png)
![tab1](https://user-images.githubusercontent.com/32623706/46898093-c91b2280-ce7e-11e8-8af6-1791625f8a02.png)
![tab2](https://user-images.githubusercontent.com/32623706/46898095-c9b3b900-ce7e-11e8-9b60-f9a564f36e06.png)
![web-build_2018-10-10t00_53_54 933z_ti8q 2fnexus4-19-en_us-portrait 2fartifacts 2f1](https://user-images.githubusercontent.com/32623706/46898096-c9b3b900-ce7e-11e8-9300-25fa3ee4d0b5.png)

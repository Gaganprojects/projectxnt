package com.raugfer.crypto;

public class triple<L, R, T> {

    public L l;
    public R r;
    public T t;

    public triple(L l, R r, T t) {
        this.l = l;
        this.r = r;
        this.t = t;
    }

}
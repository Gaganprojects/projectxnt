package com.raugfer.crypto;

public class pair<L, R> {

    public L l;
    public R r;

    public pair(L l, R r) {
        this.l = l;
        this.r = r;
    }

}

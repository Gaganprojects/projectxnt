package org.knowm.xchange.binance.dto.account;

public abstract class SapiResponse<T> {

  public abstract T getData();
}

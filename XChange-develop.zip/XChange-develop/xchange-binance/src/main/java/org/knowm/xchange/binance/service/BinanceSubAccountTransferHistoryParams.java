package org.knowm.xchange.binance.service;

import org.knowm.xchange.service.trade.params.DefaultTradeHistoryParamsTimeSpan;

public class BinanceSubAccountTransferHistoryParams extends DefaultTradeHistoryParamsTimeSpan {}

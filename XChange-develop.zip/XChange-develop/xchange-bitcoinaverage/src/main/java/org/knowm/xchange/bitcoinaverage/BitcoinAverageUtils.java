package org.knowm.xchange.bitcoinaverage;

/** A central place for shared BitcoinAverage properties */
public final class BitcoinAverageUtils {

  /** private Constructor */
  private BitcoinAverageUtils() {}
}

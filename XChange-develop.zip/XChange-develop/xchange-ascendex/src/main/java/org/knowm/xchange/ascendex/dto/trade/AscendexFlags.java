package org.knowm.xchange.ascendex.dto.trade;

import org.knowm.xchange.dto.Order;

public enum AscendexFlags implements Order.IOrderFlags {
  POST_ONLY;
}

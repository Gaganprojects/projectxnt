package org.knowm.xchange.bitcoincore.dto.account;

public class BitcoinCoreBalanceRequest {

  public String getMethod() {
    return "getbalance";
  }
}

package org.knowm.xchange.bitcoincore.dto.account;

public class BitcoinCoreUnconfirmedBalanceRequest {

  public String getMethod() {
    return "getunconfirmedbalance";
  }
}

package org.knowm.xchange.bibox.dto;

/**
 * Just an object that will be JSON serialized to {} Often needed when there are no parameters for a
 * command
 *
 * @author odrotleff
 */
public class BiboxEmptyBody {
  public BiboxEmptyBody() {}
}

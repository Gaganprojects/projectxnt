package org.knowm.xchange.bibox.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BiboxAllAssetsBody {

  @JsonProperty public final int select = 1;

  public BiboxAllAssetsBody() {}
}

var Loader = React.createClass({
    render() { 
        return (<div className="loadingio-spinner-square-iyrjry8g9g9"><div className="ldio-wdnt6erfulc">
        <div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>
        </div></div>);
    }
});
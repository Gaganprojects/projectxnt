export interface TempState {}

export default {
} as TempState;

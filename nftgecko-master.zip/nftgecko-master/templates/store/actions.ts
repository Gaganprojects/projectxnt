import { ActionTree } from "vuex";
import { ActionName } from "./name";
import { TempState } from "./state";

const actions: ActionTree<TempState, any> = {};

export default actions;

import { MutationTree } from "vuex";
import { MutationName } from "./name";
import { TempState } from "./state";

const mutations: MutationTree<TempState> = {};

export default mutations;

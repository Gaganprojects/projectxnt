import { GetterTree } from "vuex";
import { GetterName } from "./name";
import { TempState } from "./state";

const getters: GetterTree<TempState, any> = {};

export default getters;

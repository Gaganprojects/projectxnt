export const ActionName = {};
export const GetterName = {};
export const MutationName = {};

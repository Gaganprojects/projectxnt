<template>
  <q-page padding>
    <!-- content -->
  </q-page>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component({
  name: "PageName"
})
class ComponentName extends Vue {}

export default ComponentName;
</script>

<style></style>

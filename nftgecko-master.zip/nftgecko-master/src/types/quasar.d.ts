declare module "quasar";

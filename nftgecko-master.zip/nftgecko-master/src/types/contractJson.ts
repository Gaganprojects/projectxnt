import cgJson from "src/contracts/contract/ethereum/coingecko/contract.json";

export type ContractJson = typeof cgJson;

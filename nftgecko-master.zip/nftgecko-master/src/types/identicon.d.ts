declare module "identicon.js";

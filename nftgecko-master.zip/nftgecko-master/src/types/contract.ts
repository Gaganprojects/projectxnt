export type getSupportImgShortcutFunc = () => boolean;
export type genImgFunc = (payload: { id: number }, jsonData?: any) => string;
export type genNFTFunc = (payload: { id: number }) => void;

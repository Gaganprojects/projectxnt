import en from "./en.json";

const locale = { "en-us": en };

export default locale;
